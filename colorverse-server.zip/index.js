// index.js - Entry point for server
